# Gender-Recognition-System
This is a ML based project which is trained to recognize gender from the photo. You have two options, either you capture photo from our site or upload your photo on site. Web Development has been done with the help of FLASK in Python. In this we have applied PCA(Principal Component Analysis) and is totally ML-based. And we have applied ensemble model.

Features:<br>
-The user can input an image for the model to detect the gender of the person<br>
-The project also allows users to capture their picture and detect the gender of the captured person in real time

